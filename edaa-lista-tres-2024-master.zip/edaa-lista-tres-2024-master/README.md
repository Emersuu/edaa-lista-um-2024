## Algoritmos

Bubble Sort / Selection Sort / Insertion Sort / Quick Sort