//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package org.app;

import java.util.Scanner;

public class App {
    public static void main(String[] args) {

        System.out.println("Atividade 1:\n");

        Atividades.Atividade1();

        System.out.println("\nAtividade 2:\n");

        Atividades.Atividade2();

        System.out.println("\nAtividade 3:\n");

        Atividades.Atividade3();

        System.out.println("\nAtividade 4:\n");

        Atividades.Atividade4();

        System.out.println("\nAtividade 5:\n");

        Atividades.Atividade5();

    }
}
